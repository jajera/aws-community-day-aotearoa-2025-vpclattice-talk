exports.handler = async (event) => {
    console.log('Payments Service Event:', JSON.stringify(event, null, 2));

    // Simple solution: always return payments data since VPC Lattice routes to us
    const response = {
        statusCode: 200,
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        body: JSON.stringify({
            service: 'payments',
            message: 'Payment processing service',
            payments: [
                { id: 'PAY-001', orderId: 'ORD-001', amount: 1199.98, status: 'completed', method: 'credit_card' },
                { id: 'PAY-002', orderId: 'ORD-002', amount: 169.98, status: 'pending', method: 'paypal' },
                { id: 'PAY-003', orderId: 'ORD-003', amount: 299.97, status: 'failed', method: 'credit_card' }
            ],
            timestamp: new Date().toISOString()
        })
    };

    return response;
};
