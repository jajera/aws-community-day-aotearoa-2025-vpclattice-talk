exports.handler = async (event) => {
    console.log('Analytics Service Event:', JSON.stringify(event, null, 2));

    // Simple solution: always return analytics data since VPC Lattice routes to us
    const response = {
        statusCode: 200,
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        body: JSON.stringify({
            service: 'analytics',
            message: 'Business intelligence service',
            metrics: {
                totalOrders: 1250,
                totalRevenue: 125000.50,
                averageOrderValue: 100.00,
                topProducts: [
                    { productId: 1, name: 'Laptop', sales: 150, revenue: 149998.50 },
                    { productId: 3, name: 'Headphones', sales: 200, revenue: 29998.00 },
                    { productId: 2, name: 'Book', sales: 500, revenue: 9995.00 }
                ],
                conversionRate: 3.2,
                customerSatisfaction: 4.7
            },
            timestamp: new Date().toISOString()
        })
    };

    return response;
};
