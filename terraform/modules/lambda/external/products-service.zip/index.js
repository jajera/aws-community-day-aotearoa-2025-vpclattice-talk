exports.handler = async (event) => {
    console.log('Products Service V1 Event:', JSON.stringify(event, null, 2));

    // Simple V1 API - basic product listing
    const response = {
        statusCode: 200,
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'X-API-Version': '1.0',
            'X-Source': 'lambda-v1'
        },
        body: JSON.stringify({
            api_version: '1.0',
            service: 'products-v1',
            message: 'Basic Product Catalog Service V1',
            products: [
                { id: 1, name: 'Laptop', price: 999.99, category: 'Electronics' },
                { id: 2, name: 'Book', price: 19.99, category: 'Education' },
                { id: 3, name: 'Headphones', price: 149.99, category: 'Electronics' }
            ],
            timestamp: new Date().toISOString(),
            version_info: {
                lambda_version: '1.0',
                deployment_date: '2024-01-01',
                features: ['Basic Product Listing']
            }
        })
    };

    return response;
};
