exports.handler = async (event) => {
    console.log('User Service Event:', JSON.stringify(event, null, 2));

    const response = {
        statusCode: 200,
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        body: JSON.stringify({
            message: 'User Service - Managing user data',
            service: 'user-service',
            timestamp: new Date().toISOString(),
            event: event
        })
    };

    return response;
};
