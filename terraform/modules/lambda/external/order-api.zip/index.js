exports.handler = async (event) => {
    console.log('Order API Event:', JSON.stringify(event, null, 2));

    const response = {
        statusCode: 200,
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        body: JSON.stringify({
            message: 'Order API - Processing order request',
            service: 'order-api',
            timestamp: new Date().toISOString(),
            event: event
        })
    };

    return response;
};
