exports.handler = async (event) => {
    console.log('Not Found Service Event:', JSON.stringify(event, null, 2));

    const path = event.requestContext?.http?.path || event.path || event.rawPath || '/';

    const response = {
        statusCode: 404,
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        body: JSON.stringify({
            error: 'Not Found',
            message: 'The requested endpoint does not exist',
            path: path,
            availableEndpoints: [
                '/products',
                '/orders',
                '/payments',
                '/inventory',
                '/analytics'
            ],
            timestamp: new Date().toISOString()
        })
    };

    return response;
};
