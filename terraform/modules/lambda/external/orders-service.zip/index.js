exports.handler = async (event) => {
    console.log('Orders Service Event:', JSON.stringify(event, null, 2));

    // Simple solution: always return orders data since VPC Lattice routes to us
    const response = {
        statusCode: 200,
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        body: JSON.stringify({
            service: 'orders',
            message: 'Order management service',
            orders: [
                { id: 'ORD-001', customerId: 'CUST-123', total: 1199.98, status: 'processing' },
                { id: 'ORD-002', customerId: 'CUST-456', total: 169.98, status: 'shipped' },
                { id: 'ORD-003', customerId: 'CUST-789', total: 299.97, status: 'delivered' }
            ],
            timestamp: new Date().toISOString()
        })
    };

    return response;
};
