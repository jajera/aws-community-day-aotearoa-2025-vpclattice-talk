exports.handler = async (event) => {
    console.log('Inventory Service Event:', JSON.stringify(event, null, 2));

    // Simple solution: always return inventory data since VPC Lattice routes to us
    const response = {
        statusCode: 200,
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        body: JSON.stringify({
            service: 'inventory',
            message: 'Inventory management service',
            inventory: [
                { productId: 1, name: 'Laptop', quantity: 25, reserved: 5, available: 20 },
                { productId: 2, name: 'Book', quantity: 100, reserved: 10, available: 90 },
                { productId: 3, name: 'Headphones', quantity: 50, reserved: 8, available: 42 }
            ],
            timestamp: new Date().toISOString()
        })
    };

    return response;
};
