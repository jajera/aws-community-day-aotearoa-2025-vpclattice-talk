exports.handler = async (event) => {
    console.log('Products Service V2 Event:', JSON.stringify(event, null, 2));

    // Enhanced V2 API with more features
    const requestId = event.requestContext?.requestId || 'unknown';
    const userAgent = event.headers?.['user-agent'] || 'unknown';
    const sourceIp = event.requestContext?.http?.sourceIp || 'unknown';

    // V2 Enhanced product catalog with more details
    const products = [
        {
            id: 1,
            name: 'MacBook Pro M3',
            price: 1999.99,
            category: 'Electronics',
            brand: 'Apple',
            inStock: true,
            rating: 4.8,
            features: ['M3 Chip', '16GB RAM', '512GB SSD'],
            description: 'Latest MacBook Pro with M3 chip for professional use'
        },
        {
            id: 2,
            name: 'JavaScript: The Definitive Guide',
            price: 49.99,
            category: 'Education',
            brand: 'O\'Reilly',
            inStock: true,
            rating: 4.9,
            features: ['Hardcover', '1200+ Pages', 'Latest Edition'],
            description: 'Comprehensive guide to JavaScript programming'
        },
        {
            id: 3,
            name: 'Sony WH-1000XM5',
            price: 399.99,
            category: 'Electronics',
            brand: 'Sony',
            inStock: false,
            rating: 4.7,
            features: ['Noise Cancelling', '30hr Battery', 'Hi-Res Audio'],
            description: 'Premium noise-cancelling wireless headphones'
        },
        {
            id: 4,
            name: 'Standing Desk Pro',
            price: 299.99,
            category: 'Furniture',
            brand: 'FlexiSpot',
            inStock: true,
            rating: 4.6,
            features: ['Electric Height Adjustment', 'Memory Presets', 'Cable Management'],
            description: 'Ergonomic electric standing desk for home office'
        }
    ];

    // V2 API Response with enhanced metadata
    const response = {
        statusCode: 200,
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'X-API-Version': '2.0',
            'X-Request-ID': requestId,
            'X-Source': 'lambda-v2'
        },
        body: JSON.stringify({
            api_version: '2.0',
            service: 'products-v2',
            message: 'Enhanced Product Catalog Service V2',
            metadata: {
                total_products: products.length,
                in_stock_count: products.filter(p => p.inStock).length,
                categories: [...new Set(products.map(p => p.category))],
                request_id: requestId,
                source_ip: sourceIp,
                user_agent: userAgent,
                execution_time: Date.now()
            },
            products: products,
            pagination: {
                page: 1,
                per_page: products.length,
                total_pages: 1
            },
            timestamp: new Date().toISOString(),
            version_info: {
                lambda_version: '2.0',
                deployment_date: '2024-01-15',
                features: ['Enhanced Product Details', 'Inventory Status', 'Ratings', 'Advanced Filtering']
            }
        })
    };

    return response;
};
